#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"



void
on_button1_insc_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
FILE *f =NULL;
GtkWidget *login,*pw, *windowAuth;
char login1[20];
char passw [20];
login = lookup_widget (button, "entry1_nom");
pw = lookup_widget (button, "entry2_Mot");
strcpy(login1, gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(passw, gtk_entry_get_text(GTK_ENTRY(pw)));
//ouvrir le fichier
f=fopen("utilisateur.txt","a");
if(f!=NULL)
{
//ecrire dans le fichier
fprintf(f,"%s %s \n",login1,passw);
fclose(f);

}
else
printf("\n Not found");

windowAuth=create_authen();
gtk_widget_show (windowAuth);

}
void
on_button2_auth_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *username, *password, *windowEspaceAdmin;
char user[20];
char pasw[20];
int trouve;
username = lookup_widget (button, "entry3_log");
password = lookup_widget (button, "entry4_Pw");

strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=verif(user,pasw);

if(trouve==1)
{
windowEspaceAdmin=create_Admin();
 gtk_widget_show (windowEspaceAdmin);
}


}
