#include <gtk/gtk.h>


void
on_button1_insc_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_auth_clicked                (GtkButton       *button,
                                        gpointer         user_data);
